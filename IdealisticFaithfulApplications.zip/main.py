from time import time

#deletes hello but not the function. Funcs act like vars, their first class citizens
def hello():
  print('helllloooooooo')

greet = hello
del hello

print(greet())
print("")

#The thing below is a bit weird but youll see.
#"hello" calls the param as a function, meaning that you didn't have to call greet with the "()"
#"hello" is a higher order function
def hello(func):
  func()

def greet():
  print('still here')

a = hello(greet)

print(a)
print("")

#Decorators
def hello():
  print('hello')

def my_decorator(func):
  def wrap_func():
    #can add anything in here
    func()
    #this is way deco's are vvv useful 
  return wrap_func

@my_decorator
def hello():
  print('hello')

hello()


def preformance(fn):
  def wrapper(*args, **kawrgs):
    t1 = time()
    result = fn(*args, **kawargs)
    t2 = time()
    print(f'took {t2-t1} s')
    return result
  return wrapper

@preformance
def lg():
  for i in range(10000000):
    i*5

