#lambda expression pog!!!

#lambda param: manipulation(param) <-- format for lambdas

def multiply2(item):
  return item*2

my_list = [1,2,3]

print("this one is very clean and only one line long")

print(list(map(lambda item: item*2, my_list)))

print("")

print("this one took 3 lines of code")

print(list(map(multiply2, my_list)))

#lambda functions can be very useful and versitle, it does make code a little harder to read which creates a trade off

#squaring a list

print("")
print("Exercise (Sqauring)")

my_list2 = [1,2,3]
print(list(map(lambda item: item**2, my_list)))

print("")
print("Exercise (Sorting) <-- Kinda wack")

a = [(0,2), (4,3), (10,-1), (9,9)]
a.sort(key=lambda x: x[1])
print(a)

print("Sorted by second number in tuple ^^")

#list, set, dictionary. Loops in lists and shit? What!!!


print("")
print("Ez Pz")

my_list3 = [char for char in "hello"]
print(my_list3)

print("")
print("Ez Pz No. 2")
 
ano_list = [num for num in range(0,10)]
ano_list2 = [num**2 for num in range(0,10)]
print(ano_list)
print(ano_list2)

print("")
print("Dictionary (wth is this?")


my_dict = {num:num*2 for num in [1,2,3]}

print(my_dict)

some_list = ["a", "b", "c", "b", "d", "m", "n", "n"]

duplicates = list(set([x for x in some_list if some_list.count(x) > 1]))

print(duplicates)